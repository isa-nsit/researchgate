  var r1 = document.getElementById('task_members_count_1');
  var r2 = document.getElementById('task_members_count_2');
  var r3 = document.getElementById('task_members_count_3');
  var r4 = document.getElementById('task_members_count_4');
  var r5 = document.getElementById('task_members_count_5');

  var emails = document.getElementById('emails');
  var k = []

  var valid_array = [];

  for(var i=0;i<7;i++)
    valid_array[i] = false;

  valid_array[2] = true;
  valid_array[5] = true;
  valid_array[6] = true;


  k = Array.from(emails.children)
  
  var n = k.length

  for(var i=0;i<n;i++)
    k[i].style.display = "none";

  var email2_val = false;
  var email3_val = false;
  var email4_val = false;
  var email5_val = false;

  r1.addEventListener('change',function (event) {
    k[0].style.display = "none";
    k[1].style.display = "none";
    k[2].style.display = "none";
    k[3].style.display = "none";

    var result = false;
    for(var i = 0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

    submit_button.disabled = result;
  });
  
  r2.addEventListener('change',function (event) {
    k[0].style.display = "block";
    k[1].style.display = "none";
    k[2].style.display = "none";
    k[3].style.display = "none";

    email2.addEventListener('input',function(){

     var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      if(!result && val2>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });
  var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;   

      val2 = email2.value.length;
      
      if(!result && val2)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;  
  });

  r3.addEventListener('change',function (event) {
    k[0].style.display = "block";
    k[1].style.display = "block";
    k[2].style.display = "none";
    k[3].style.display = "none";

    email2.addEventListener('input',function(){

     var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;

      if(!result && val2>0 && val3>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });

    email3.addEventListener('input',function(){

      var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      
      if(!result && val2>0 && val3>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });
  var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;   

      val2 = email2.value.length;
      val3 = email3.value.length;
      if(!result && val2 && val3)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;   
  });
  
  r4.addEventListener('change',function (event) {
    k[0].style.display = "block";
    k[1].style.display = "block";
    k[2].style.display = "block";
    k[3].style.display = "none";

    email2.addEventListener('input',function(){

     var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;

      if(!result && val2>0 && val3>0 && val4>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });

    email3.addEventListener('input',function(){

      var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      

      if(!result && val2>0 && val3>0 && val4>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });

    
    email4.addEventListener('input',function(){

      var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      
      if(!result && val2>0 && val3>0 && val4>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });
  var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;   

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      
      if(!result && val2 && val3 && val4)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;  
  });
  
  r5.addEventListener('change',function (event) {
    k[0].style.display = "block";
    k[1].style.display = "block";
    k[2].style.display = "block";
    k[3].style.display = "block";

    email2.addEventListener('input',function(){

     var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      val5 = email5.value.length;

      if(!result && val2>0 && val3>0 && val4>0 && val5>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });

    email3.addEventListener('input',function(){

      var result = false;
      for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      val5 = email5.value.length;
      

      if(!result && val2>0 && val3>0 && val4>0 && val5>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });

    
    email4.addEventListener('input',function(){

      var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      val5 = email5.value.length;
      
      if(!result && val2>0 && val3>0 && val4>0 && val5>0)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;
    });

    email5.addEventListener('input',function(){

      var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      val5 = email5.value.length;
        
      if(!result && val2 && val3 && val4 && val5)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;

    });

    var result = false;
    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;   

      val2 = email2.value.length;
      val3 = email3.value.length;
      val4 = email4.value.length;
      val5 = email5.value.length;
      
      if(!result && val2 && val3 && val4 && val5)
        submit_button.disabled = false;

      else
      submit_button.disabled = true;  
  });

  
  var projectName = document.getElementById('project_name');
  var projectNameCounter = document.getElementById('project_name_counter');
  var submit_button = document.getElementById('submit_button');
  var percentage = document.getElementById('task_percentage');
  var projectDescription = document.getElementById('project_description');
  var year = document.getElementById('task_year');
  var branch = document.getElementById('task_branch');
  var email1 = document.getElementById('task_email1');
  var email2 = document.getElementById('task_email2');
  var email3 = document.getElementById('task_email3');
  var email4 = document.getElementById('task_email4');
  var email5 = document.getElementById('task_email5');
  var task_name = document.getElementById('task_name');

  submit_button.disabled = true;
  year.options[0].disabled = true;
  branch.options[0].disabled = true;
  
  // Added event Listener on ProjectName
  projectName.addEventListener('input',function(){
    if(projectName.value.length == 0)
      valid_array[0] = false;

    else
      valid_array[0] = true;
    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

    submit_button.disabled = result;
  });

  //Added event Listener on projectDescription
  projectDescription.addEventListener('input',function(){
    if(projectDescription.value.length == 0)
      valid_array[1] = false;

    else
      valid_array[1] = true;
    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;
      submit_button.disabled = result;
  });

  //Added event Listener on percentage
  percentage.addEventListener('input',function(){
    if(percentage.value.length == 0)
      valid_array[2] = false;

    else
      valid_array[2] = true;
    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;
    submit_button.disabled = result;
  });

  //Added event Listener on year
  year.addEventListener('input',function(){
    if(year.value.length == 0)
      valid_array[3] = false;

    else
      valid_array[3] = true;
    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;
    submit_button.disabled = result;
  });

  //Added event Listener on branch
  branch.addEventListener('input',function(){
    if(branch.value.length == 0)
      valid_array[4] = false;

    else
      valid_array[4] = true;
    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;
    submit_button.disabled = result;
  });

  //Added event Listener on task name
  task_name.addEventListener('input',function(){


    if(task_name.value.length == 0)
      valid_array[5] = false;

    else
      valid_array[5] = true;

    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;
    submit_button.disabled = result;
  });

  //Added event Listener on email1 
  email1.addEventListener('input',function(){

    if(email1.value.length == 0)
      valid_array[6] = false;

    else
      valid_array[6] = true;

    var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;
    submit_button.disabled = result;
  });

  var result = false;

    for(var i=0;i<7;i++)
      if(valid_array[i] == false)
        result = true;

    submit_button.disabled = result; 
